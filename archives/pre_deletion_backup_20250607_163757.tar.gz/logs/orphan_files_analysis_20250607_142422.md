
# Rapport d'Analyse des Fichiers Orphelins Oracle/Sherlock/Watson/Moriarty
Généré le 2025-06-07 14:24:22

## Résumé Exécutif
- **Fichiers scannés**: 38939
- **Fichiers avec références Oracle**: 208
- **Fichiers orphelins détectés**: 124
- **Candidats pour récupération de code**: 102

## Analyse de phase_d_extensions.py

### [OK] Code Precieux Detecte
- **Classes trouvées**: RevealationTiming, NarrativeMoment, PhaseDExtensions
- **Fonctions trouvées**: 13 fonctions
- **Lignes de code**: 604

### [RECOMMANDATIONS] Integration
- **move_to_oracle_module**: argumentation_analysis/agents/core/oracle/phase_d_extensions.py - Extensions Oracle Enhanced Phase D
- **integrate_with_oracle_state**: argumentation_analysis/core/cluedo_oracle_state.py - Extensions CluedoOracleState


## Plan d'Organisation
- **Fichiers à déplacer**: 0
- **Code à intégrer**: 103
- **Fichiers à supprimer**: 22

## Actions Recommandées

### [ACTIONS] Immediates
1. **Déplacer phase_d_extensions.py** vers `argumentation_analysis/agents/core/oracle/`
2. **Intégrer les extensions Phase D** dans `CluedoOracleState`
3. **Organiser les tests orphelins** dans `tests/orphaned/`

### [NETTOYAGE] Actions de Nettoyage
- Supprimer `GUIDE_INSTALLATION_ETUDIANTS.md` (17674 bytes) - Pas de code récupérable
- Supprimer `rapport_genere_par_agents_sk.md` (8730 bytes) - Pas de code récupérable
- Supprimer `README.md` (14155 bytes) - Pas de code récupérable
- Supprimer `examples\test_data\test_sophismes_complexes.txt` (3497 bytes) - Pas de code récupérable
- Supprimer `examples\texts\texte_analyse_temp.txt` (3495 bytes) - Pas de code récupérable
- Supprimer `venv_test\Lib\site-packages\distro\distro.py` (49430 bytes) - Pas de code récupérable
- Supprimer `venv_test\Lib\site-packages\jupyterlab\static\9296.1c75c887f933757c6bfb.js` (197547 bytes) - Pas de code récupérable
- Supprimer `venv_test\Lib\site-packages\notebook\static\2955.d8fd055f03b878034fe4.js` (474689 bytes) - Pas de code récupérable
- Supprimer `venv_test\Lib\site-packages\opentelemetry\semconv\attributes\db_attributes.py` (9034 bytes) - Pas de code récupérable
- Supprimer `venv_test\Lib\site-packages\opentelemetry\semconv\resource\__init__.py` (32978 bytes) - Pas de code récupérable
- Supprimer `venv_test\Lib\site-packages\opentelemetry\semconv\trace\__init__.py` (69390 bytes) - Pas de code récupérable
- Supprimer `venv_test\Lib\site-packages\opentelemetry\semconv\_incubating\attributes\cloud_attributes.py` (6776 bytes) - Pas de code récupérable
- Supprimer `venv_test\Lib\site-packages\opentelemetry\semconv\_incubating\attributes\db_attributes.py` (17864 bytes) - Pas de code récupérable
- Supprimer `venv_test\Lib\site-packages\opentelemetry\semconv\_incubating\attributes\faas_attributes.py` (6202 bytes) - Pas de code récupérable
- Supprimer `venv_test\Lib\site-packages\opentelemetry\semconv\_incubating\attributes\os_attributes.py` (1801 bytes) - Pas de code récupérable
- Supprimer `venv_test\Lib\site-packages\opentelemetry\semconv\_incubating\metrics\system_metrics.py` (17815 bytes) - Pas de code récupérable
- Supprimer `venv_test\Lib\site-packages\pip\_vendor\distro\distro.py` (49430 bytes) - Pas de code récupérable
- Supprimer `venv_test\Lib\site-packages\pip-25.1.1.dist-info\licenses\AUTHORS.txt` (11223 bytes) - Pas de code récupérable
- Supprimer `venv_test\Lib\site-packages\scipy\optimize\_optimize.py` (150667 bytes) - Pas de code récupérable
- Supprimer `venv_test\Lib\site-packages\transformers\models\moshi\modeling_moshi.py` (130901 bytes) - Pas de code récupérable
- Supprimer `venv_test\Lib\site-packages\transformers\pipelines\__init__.py` (55342 bytes) - Pas de code récupérable
- Supprimer `venv_test\share\jupyter\lab\static\9296.1c75c887f933757c6bfb.js` (197547 bytes) - Pas de code récupérable


## Conclusion
Le fichier **phase_d_extensions.py** contient du code précieux pour les extensions Oracle Enhanced Phase D.
Il doit être intégré dans le système Oracle Enhanced pour les fonctionnalités avancées de révélations progressives,
fausses pistes, et métriques de trace idéale.

Les autres fichiers orphelins nécessitent une révision manuelle pour déterminer leur statut d'intégration.
