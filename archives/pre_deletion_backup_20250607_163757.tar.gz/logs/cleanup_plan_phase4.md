# Plan de nettoyage Phase 4 - Tests orphelins
*Généré le 2025-06-07T15:25:42.447667*

## Résumé de l'organisation

### A Integrer (25 tests)

- **test_oracle_behavior_demo.py** (P8) - PRIORITÉ HAUTE - Récupération recommandée dans les 48h
- **test_oracle_behavior_simple.py** (P8) - PRIORITÉ HAUTE - Récupération recommandée dans les 48h
- **conftest_gpt_enhanced.py** (P8) - PRIORITÉ HAUTE - Récupération recommandée dans les 48h
- **test_mock_vs_real_behavior.py** (P9) - PRIORITÉ CRITIQUE - Récupération immédiate nécessaire
- **test_config_real_gpt.py** (P7) - PRIORITÉ HAUTE - Récupération recommandée dans les 48h
- **test_enquete_states.py** (P7) - PRIORITÉ HAUTE - Récupération recommandée dans les 48h
- **test_cluedo_extended_workflow.py** (P9) - PRIORITÉ CRITIQUE - Récupération immédiate nécessaire
- **test_cluedo_oracle_enhanced_real.py** (P7) - PRIORITÉ HAUTE - Récupération recommandée dans les 48h
- **test_einstein_demo_real.py** (P7) - PRIORITÉ HAUTE - Récupération recommandée dans les 48h
- **test_oracle_integration.py** (P9) - PRIORITÉ CRITIQUE - Récupération immédiate nécessaire
- **test_sherlock_watson_moriarty_real_gpt.py** (P9) - PRIORITÉ CRITIQUE - Récupération immédiate nécessaire
- **test_oracle_performance.py** (P7) - PRIORITÉ HAUTE - Récupération recommandée dans les 48h
- **test_error_handling.py** (P7) - PRIORITÉ HAUTE - Récupération recommandée dans les 48h
- **test_cluedo_dataset.py** (P9) - PRIORITÉ CRITIQUE - Récupération immédiate nécessaire
- **test_dataset_access_manager.py** (P7) - PRIORITÉ HAUTE - Récupération recommandée dans les 48h
- **test_moriarty_interrogator_agent.py** (P9) - PRIORITÉ CRITIQUE - Récupération immédiate nécessaire
- **test_oracle_base_agent.py** (P8) - PRIORITÉ HAUTE - Récupération recommandée dans les 48h
- **test_oracle_base_agent_fixed.py** (P8) - PRIORITÉ HAUTE - Récupération recommandée dans les 48h
- **test_oracle_enhanced_behavior.py** (P8) - PRIORITÉ HAUTE - Récupération recommandée dans les 48h
- **test_cluedo_oracle_state.py** (P9) - PRIORITÉ CRITIQUE - Récupération immédiate nécessaire
- **test_cluedo_enhanced_orchestrator.py** (P9) - PRIORITÉ CRITIQUE - Récupération immédiate nécessaire
- **test_scripts_execution.py** (P8) - PRIORITÉ HAUTE - Récupération recommandée dans les 48h
- **test_phase_a_personnalites_distinctes.py** (P9) - PRIORITÉ CRITIQUE - Récupération immédiate nécessaire
- **test_phase_b_naturalite_dialogue.py** (P7) - PRIORITÉ HAUTE - Récupération recommandée dans les 48h
- **test_phase_c_fluidite_transitions.py** (P8) - PRIORITÉ HAUTE - Récupération recommandée dans les 48h

### A Moderniser (0 tests)


### A Archiver (12 tests)

- **test_einstein_simple.py** (P4) - PRIORITÉ BASSE - Récupération optionnelle
- **demo_tests_validation.py** (P5) - PRIORITÉ MOYENNE - Récupération à planifier
- **fix_failing_tests.py** (P4) - PRIORITÉ BASSE - Récupération optionnelle
- **debug_jni_leak.py** (P4) - PRIORITÉ BASSE - Récupération optionnelle
- **test_watson_logic_assistant.py** (P4) - PRIORITÉ BASSE - Récupération optionnelle
- **test_sherlock_enquete_agent.py** (P4) - PRIORITÉ BASSE - Récupération optionnelle
- **test_cluedo_orchestration_integration.py** (P5) - PRIORITÉ MOYENNE - Récupération à planifier
- **test_enquete_state_manager_plugin.py** (P4) - PRIORITÉ BASSE - Récupération optionnelle
- **test_final_oracle_100_percent.py** (P4) - PRIORITÉ BASSE - Récupération optionnelle
- **test_final_oracle_fixes.py** (P4) - PRIORITÉ BASSE - Récupération optionnelle
- **test_group3_fixes.py** (P4) - PRIORITÉ BASSE - Récupération optionnelle
- **test_phase_b_simple.py** (P4) - PRIORITÉ BASSE - Récupération optionnelle

### A Supprimer (7 tests)

- **fix_final_test.py** (P2) - PRIORITÉ MINIMALE - Archivage ou suppression
- **validation_phase_b.py** (P2) - PRIORITÉ MINIMALE - Archivage ou suppression
- **test_cluedo_demo.py** (P2) - PRIORITÉ MINIMALE - Archivage ou suppression
- **test_asyncmock_issues.py** (P2) - PRIORITÉ MINIMALE - Archivage ou suppression
- **test_audit_integrite_cluedo.py** (P6) - PRIORITÉ MOYENNE - Récupération à planifier
- **test_diagnostic.py** (P2) - PRIORITÉ MINIMALE - Archivage ou suppression
- **test_validation_integrite_apres_corrections.py** (P6) - PRIORITÉ MOYENNE - Récupération à planifier

## Actions de nettoyage recommandées

### Phase 4A - Validation des intégrations
- [ ] Tester les tests intégrés dans `tests/integration/`
- [ ] Valider la compatibilité Oracle Enhanced v2.1.0
- [ ] Corriger les éventuelles incompatibilités

### Phase 4B - Modernisation
- [ ] Adapter les tests dans `tests/validation/modernized/`
- [ ] Mettre à jour les APIs obsolètes
- [ ] Harmoniser avec les standards actuels

### Phase 4C - Archivage sécurisé
- [ ] Compresser les tests archivés
- [ ] Créer un index de recherche
- [ ] Documenter l'historique

### Phase 4D - Suppression définitive
- [ ] Valider que les tests deprecated ne sont plus référencés
- [ ] Supprimer définitivement après validation
- [ ] Nettoyer les imports et références