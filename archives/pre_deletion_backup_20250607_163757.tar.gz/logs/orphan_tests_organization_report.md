# Rapport d'organisation des tests orphelins

*Généré le 2025-06-07T15:25:42.447667*

## Résumé exécutif

**Total analysé:** 44 tests orphelins

- **A Integrer:** 25 tests
- **A Moderniser:** 0 tests
- **A Archiver:** 12 tests
- **A Supprimer:** 7 tests

## Catégorisation détaillée

### A Integrer

**test_oracle_behavior_demo.py**
- Priorité: 8
- Confiance: 0.70
- Références Oracle: 80
- Justification: Test haute valeur (P8, conf=0.70, 80 refs Oracle) avec potentiel d'intégration test_file

**test_oracle_behavior_simple.py**
- Priorité: 8
- Confiance: 0.70
- Références Oracle: 80
- Justification: Test haute valeur (P8, conf=0.70, 80 refs Oracle) avec potentiel d'intégration test_file

**conftest_gpt_enhanced.py**
- Priorité: 8
- Confiance: 0.65
- Références Oracle: 23
- Justification: Test haute valeur (P8, conf=0.65, 23 refs Oracle) avec potentiel d'intégration integrated

**test_mock_vs_real_behavior.py**
- Priorité: 9
- Confiance: 0.65
- Références Oracle: 40
- Justification: Test haute valeur (P9, conf=0.65, 40 refs Oracle) avec potentiel d'intégration integrated

**test_config_real_gpt.py**
- Priorité: 7
- Confiance: 0.80
- Références Oracle: 6
- Justification: Test haute valeur (P7, conf=0.80, 6 refs Oracle) avec potentiel d'intégration test_file

**test_enquete_states.py**
- Priorité: 7
- Confiance: 1.00
- Références Oracle: 1
- Justification: Test haute valeur (P7, conf=1.00, 1 refs Oracle) avec potentiel d'intégration test_file

**test_cluedo_extended_workflow.py**
- Priorité: 9
- Confiance: 0.75
- Références Oracle: 64
- Justification: Test haute valeur (P9, conf=0.75, 64 refs Oracle) avec potentiel d'intégration integrated

**test_cluedo_oracle_enhanced_real.py**
- Priorité: 7
- Confiance: 0.90
- Références Oracle: 10
- Justification: Test haute valeur (P7, conf=0.90, 10 refs Oracle) avec potentiel d'intégration test_file

**test_einstein_demo_real.py**
- Priorité: 7
- Confiance: 0.90
- Références Oracle: 11
- Justification: Test haute valeur (P7, conf=0.90, 11 refs Oracle) avec potentiel d'intégration test_file

**test_oracle_integration.py**
- Priorité: 9
- Confiance: 0.75
- Références Oracle: 52
- Justification: Test haute valeur (P9, conf=0.75, 52 refs Oracle) avec potentiel d'intégration integrated

**test_sherlock_watson_moriarty_real_gpt.py**
- Priorité: 9
- Confiance: 0.65
- Références Oracle: 37
- Justification: Test haute valeur (P9, conf=0.65, 37 refs Oracle) avec potentiel d'intégration integrated

**test_oracle_performance.py**
- Priorité: 7
- Confiance: 0.65
- Références Oracle: 13
- Justification: Test haute valeur (P7, conf=0.65, 13 refs Oracle) avec potentiel d'intégration integrated

**test_error_handling.py**
- Priorité: 7
- Confiance: 0.65
- Références Oracle: 6
- Justification: Test haute valeur (P7, conf=0.65, 6 refs Oracle) avec potentiel d'intégration integrated

**test_cluedo_dataset.py**
- Priorité: 9
- Confiance: 0.65
- Références Oracle: 37
- Justification: Test haute valeur (P9, conf=0.65, 37 refs Oracle) avec potentiel d'intégration integrated

**test_dataset_access_manager.py**
- Priorité: 7
- Confiance: 0.75
- Références Oracle: 16
- Justification: Test haute valeur (P7, conf=0.75, 16 refs Oracle) avec potentiel d'intégration integrated

**test_moriarty_interrogator_agent.py**
- Priorité: 9
- Confiance: 0.75
- Références Oracle: 35
- Justification: Test haute valeur (P9, conf=0.75, 35 refs Oracle) avec potentiel d'intégration integrated

**test_oracle_base_agent.py**
- Priorité: 8
- Confiance: 0.75
- Références Oracle: 29
- Justification: Test haute valeur (P8, conf=0.75, 29 refs Oracle) avec potentiel d'intégration integrated

**test_oracle_base_agent_fixed.py**
- Priorité: 8
- Confiance: 0.75
- Références Oracle: 28
- Justification: Test haute valeur (P8, conf=0.75, 28 refs Oracle) avec potentiel d'intégration integrated

**test_oracle_enhanced_behavior.py**
- Priorité: 8
- Confiance: 0.65
- Références Oracle: 29
- Justification: Test haute valeur (P8, conf=0.65, 29 refs Oracle) avec potentiel d'intégration integrated

**test_cluedo_oracle_state.py**
- Priorité: 9
- Confiance: 0.75
- Références Oracle: 68
- Justification: Test haute valeur (P9, conf=0.75, 68 refs Oracle) avec potentiel d'intégration integrated

**test_cluedo_enhanced_orchestrator.py**
- Priorité: 9
- Confiance: 0.65
- Références Oracle: 31
- Justification: Test haute valeur (P9, conf=0.65, 31 refs Oracle) avec potentiel d'intégration integrated

**test_scripts_execution.py**
- Priorité: 8
- Confiance: 0.90
- Références Oracle: 19
- Justification: Test haute valeur (P8, conf=0.90, 19 refs Oracle) avec potentiel d'intégration test_file

**test_phase_a_personnalites_distinctes.py**
- Priorité: 9
- Confiance: 0.70
- Références Oracle: 67
- Justification: Test haute valeur (P9, conf=0.70, 67 refs Oracle) avec potentiel d'intégration test_file

**test_phase_b_naturalite_dialogue.py**
- Priorité: 7
- Confiance: 0.70
- Références Oracle: 8
- Justification: Test haute valeur (P7, conf=0.70, 8 refs Oracle) avec potentiel d'intégration test_file

**test_phase_c_fluidite_transitions.py**
- Priorité: 8
- Confiance: 0.45
- Références Oracle: 23
- Justification: Test haute valeur (P8, conf=0.45, 23 refs Oracle) avec potentiel d'intégration integrated

### A Moderniser

### A Archiver

**test_einstein_simple.py**
- Priorité: 4
- Confiance: 0.80
- Références Oracle: 11
- Justification: Test historique (P4) conservé pour référence et documentation du projet

**demo_tests_validation.py**
- Priorité: 5
- Confiance: 0.70
- Références Oracle: 18
- Justification: Test historique (P5) conservé pour référence et documentation du projet

**fix_failing_tests.py**
- Priorité: 4
- Confiance: 0.90
- Références Oracle: 5
- Justification: Test historique (P4) conservé pour référence et documentation du projet

**debug_jni_leak.py**
- Priorité: 4
- Confiance: 0.70
- Références Oracle: 1
- Justification: Test historique (P4) conservé pour référence et documentation du projet

**test_watson_logic_assistant.py**
- Priorité: 4
- Confiance: 0.65
- Références Oracle: 5
- Justification: Test historique (P4) conservé pour référence et documentation du projet

**test_sherlock_enquete_agent.py**
- Priorité: 4
- Confiance: 0.90
- Références Oracle: 1
- Justification: Test historique (P4) conservé pour référence et documentation du projet

**test_cluedo_orchestration_integration.py**
- Priorité: 5
- Confiance: 1.00
- Références Oracle: 27
- Justification: Test historique (P5) conservé pour référence et documentation du projet

**test_enquete_state_manager_plugin.py**
- Priorité: 4
- Confiance: 0.90
- Références Oracle: 4
- Justification: Test historique (P4) conservé pour référence et documentation du projet

**test_final_oracle_100_percent.py**
- Priorité: 4
- Confiance: 0.80
- Références Oracle: 15
- Justification: Test historique (P4) conservé pour référence et documentation du projet

**test_final_oracle_fixes.py**
- Priorité: 4
- Confiance: 0.80
- Références Oracle: 7
- Justification: Test historique (P4) conservé pour référence et documentation du projet

**test_group3_fixes.py**
- Priorité: 4
- Confiance: 0.65
- Références Oracle: 10
- Justification: Test historique (P4) conservé pour référence et documentation du projet

**test_phase_b_simple.py**
- Priorité: 4
- Confiance: 0.80
- Références Oracle: 8
- Justification: Test historique (P4) conservé pour référence et documentation du projet

### A Supprimer

**fix_final_test.py**
- Priorité: 2
- Confiance: 0.80
- Références Oracle: 1
- Justification: Test obsolète (P2, conf=0.80) sans valeur ajoutée identifiée

**validation_phase_b.py**
- Priorité: 2
- Confiance: 0.40
- Références Oracle: 9
- Justification: Test obsolète (P2, conf=0.40) sans valeur ajoutée identifiée

**test_cluedo_demo.py**
- Priorité: 2
- Confiance: 1.00
- Références Oracle: 12
- Justification: Test obsolète (P2, conf=1.00) sans valeur ajoutée identifiée

**test_asyncmock_issues.py**
- Priorité: 2
- Confiance: 0.90
- Références Oracle: 1
- Justification: Test obsolète (P2, conf=0.90) sans valeur ajoutée identifiée

**test_audit_integrite_cluedo.py**
- Priorité: 6
- Confiance: 0.65
- Références Oracle: 36
- Justification: Test obsolète (P6, conf=0.65) sans valeur ajoutée identifiée

**test_diagnostic.py**
- Priorité: 2
- Confiance: 0.80
- Références Oracle: 2
- Justification: Test obsolète (P2, conf=0.80) sans valeur ajoutée identifiée

**test_validation_integrite_apres_corrections.py**
- Priorité: 6
- Confiance: 0.65
- Références Oracle: 33
- Justification: Test obsolète (P6, conf=0.65) sans valeur ajoutée identifiée

## Analyse d'intégration

**Tests haute valeur à intégrer:** 25
- test_oracle_behavior_demo.py
- test_oracle_behavior_simple.py
- conftest_gpt_enhanced.py
- test_mock_vs_real_behavior.py
- test_config_real_gpt.py
- test_enquete_states.py
- test_cluedo_extended_workflow.py
- test_cluedo_oracle_enhanced_real.py
- test_einstein_demo_real.py
- test_oracle_integration.py
- test_sherlock_watson_moriarty_real_gpt.py
- test_oracle_performance.py
- test_error_handling.py
- test_cluedo_dataset.py
- test_dataset_access_manager.py
- test_moriarty_interrogator_agent.py
- test_oracle_base_agent.py
- test_oracle_base_agent_fixed.py
- test_oracle_enhanced_behavior.py
- test_cluedo_oracle_state.py
- test_cluedo_enhanced_orchestrator.py
- test_scripts_execution.py
- test_phase_a_personnalites_distinctes.py
- test_phase_b_naturalite_dialogue.py
- test_phase_c_fluidite_transitions.py

**Candidats à la modernisation:** 0

## Recommandations

1. **Intégration immédiate** des tests haute valeur
2. **Modernisation progressive** des candidats identifiés
3. **Archivage sécurisé** des tests historiques
4. **Suppression contrôlée** des tests obsolètes
